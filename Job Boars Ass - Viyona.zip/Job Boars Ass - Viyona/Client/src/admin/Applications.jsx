import React, { useEffect, useState } from 'react'
import UserNav from '../navbars/UserNav';
import axios from 'axios';
import { useForm } from 'react-hook-form';
import toast, { Toaster } from 'react-hot-toast';
import AdminNav from '../navbars/AdminNav';

const Applications = () => {
      const [tasks, setTasks] = useState([]);
      const [editData, setEditData] = useState({});
      const editForm = useForm();
      const [message, setmessage] = useState('Pending');
      const getEditData = (data) => {
        console.log(data);
        setEditData(data);
        editForm.setValue("title", data.title);
        editForm.setValue("description", data.description);
      };
    const getAllTasks = async () => {
        try {
          const res = await axios.get(`http://127.0.0.1:8000/jobs/jobs`);
          if (res.status === 200) {
            setTasks(res.data);
          }
        } catch (error) {
          console.log(error);
        }
      };
      useEffect(() => {
        getAllTasks();
      }, []);
  return (
    <div>
        <AdminNav/>
        <div className="card mt-5">
        <div className="card-body">
          <div className="h5">All Jobs</div>
          <div style={{ overflowX: "auto" }}>
            <table className="table table-bordered text-center mt-3">
              <thead>
                <tr>
                  <th>S.No</th>
                  <th>Title</th>
                  <th>Description</th>
                  <th>Company</th>
                  <th>Location</th>
                  <th>Status</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                {tasks.map((task, index) => (
                  <tr key={task._id}>
                    <td>{index + 1}</td>
                    <td>{task.title}</td>
                    <td>{task.description}</td>
                    <td>{task.company}</td>
                    <td>{task.location}</td>
                    <td>{message}</td>
                    
                    <td>
                      <button
                        className="btn btn-secondary"
                        type="button"
                        data-bs-toggle="modal"
                        data-bs-target="#editModal"
                        onClick={() => {
                          setmessage('Approved');
                          toast.success("Approved Successfully!!")
                        }
                          


                        }
                      >
                        Approve
                      </button>
                      
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
      <Toaster/>
    </div>
  )
}

export default Applications;