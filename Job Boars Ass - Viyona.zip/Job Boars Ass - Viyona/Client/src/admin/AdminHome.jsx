import React from 'react'
import AdminNav from '../navbars/AdminNav';
import Jobs from './Jobs';

const AdminHome = () => {
  return (
    <div>
        <AdminNav/>
        <Jobs/>
    </div>
  )
}

export default AdminHome;