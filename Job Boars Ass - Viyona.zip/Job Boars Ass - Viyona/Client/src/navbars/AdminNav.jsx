import { Link } from "react-router-dom";

const AdminNav = () => {
  return (
    <div>
      <nav className="navbar navbar-expand-lg bg-body-tertiary bg-info">
        <div className="container-fluid">
          <a className="navbar-brand fs-1 text-dark" href="#">
          Job Board Application
          </a>
          <button
            className="navbar-toggler"
            type="button"
            data-bs-toggle="collapse"
            data-bs-target="#navbarSupportedContent"
            aria-controls="navbarSupportedContent"
            aria-expanded="false"
            aria-label="Toggle navigation"
          >
            <span className="navbar-toggler-icon"></span>
          </button>
          <div className="collapse navbar-collapse" id="navbarSupportedContent">
           
            <ul className="navbar-nav ms-auto">
              <li className="nav-item">
                <a className="nav-link mr-5 text-dark" href="/">
                <Link className="no-underline text-dark" to="/adminhome">Home</Link>
                </a>
              </li>
              <li className="nav-item">
                <a className="nav-link mr-5" href="#">
                 <Link className="no-underline text-dark" to="/applications">Applications</Link>
                </a>
              </li>
              <li className="nav-item">
                <a className="nav-link mr-5" href="#">
                 <Link className="no-underline text-dark " to="/">Logout</Link>
                </a>
              </li>
            </ul>
          </div>
        </div>
      </nav>
    </div>
  );
};
export default AdminNav;
