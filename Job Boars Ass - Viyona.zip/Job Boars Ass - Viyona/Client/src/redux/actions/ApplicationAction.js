
import axios from 'axios';


export const GET_APPLICATIONS = "GET_APPLICATIONS";
export const CREATE_APPLICATIONS = "CREATE_APPLICATIONS";
export const UPDATE_APPLICATIONS = "UPDATE_APPLICATIONS";
export const DELETE_APPLICATIONS = "DELETE_APPLICATIONS";
export const APPLICATIONS_ERROR = "APPLICATIONS_ERROR";

export const fetchApplications = () => async (dispatch) => {
  try {
    const res = await axios.get('https://api.example.com/application');
    dispatch({
      type: GET_JOBS,
      payload: res.data,
    });
  } catch (error) {
    dispatch({
      type: APPLICATIONS_ERROR,
      payload: error.response.data.message,
    });
  }
};

export const createAppplication = (jobData) => async (dispatch) => {
  try {
    const res = await axios.post('https://api.example.com/application', jobData);
    dispatch({
      type: CREATE_APPLICATIONS,
      payload: res.data,
    });
  } catch (error) {
    dispatch({
      type: APPLICATIONS_ERROR,
      payload: error.response.data.message,
    });
  }
};

export const updateApplication = (id, updatedData) => async (dispatch) => {
  try {
    const res = await axios.put(`https://api.example.com/application/${id}`, updatedData);
    dispatch({
      type: UPDATE_APPLICATIONS,
      payload: res.data,
    });
  } catch (error) {
    dispatch({
      type: APPLICATIONS_ERROR,
      payload: error.response.data.message,
    });
  }
};


export const deleteApplication = (id) => async (dispatch) => {
  try {
    await axios.delete(`https://api.example.com/application/${id}`);
    dispatch({
      type: DELETE_APPLICATIONS,
      payload: id,
    });
  } catch (error) {
    dispatch({
      type: APPLICATIONS_ERROR,
      payload: error.response.data.message,
    });
  }
};
