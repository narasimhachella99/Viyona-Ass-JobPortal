import axios from 'axios';


export const LOGIN_SUCCESS = 'LOGIN_SUCCESS';
export const LOGIN_FAILURE = 'LOGIN_FAILURE';
export const REGISTER_SUCCESS = 'REGISTER_SUCCESS';
export const REGISTER_FAILURE = 'REGISTER_FAILURE';

export const clearMessages = () => {
    return {
        type: 'CLEAR_MESSAGES',
    };
};

export const login = (user) => async (dispatch) => {
  try {
    const response = await axios.post('http://127.0.0.1:8000/auth/auth/login',user);
    dispatch({
      type: LOGIN_SUCCESS,
      payload: response.data,
    });
  } catch (error) {
    dispatch({
      type: LOGIN_FAILURE,
      payload: error.response.data,
    });
  }
};


export const registerUser = (user) => async (dispatch) => {
  try {
    const response = await axios.post('http://127.0.0.1:8000/auth/auth/register', user);
    dispatch({
      type: REGISTER_SUCCESS,
      payload: response.data,
    });
  } catch (error) {
    dispatch({
      type: REGISTER_FAILURE,
      payload: error.response.data,
    });
  }
};
