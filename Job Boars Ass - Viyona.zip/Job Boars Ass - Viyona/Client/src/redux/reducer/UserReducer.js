
import { LOGIN_SUCCESS, LOGIN_FAILURE, REGISTER_SUCCESS, REGISTER_FAILURE } from "../actions/UserAction";

const initialState = {
  user: null,
  message: '',
  error: '',
};

const UserReducer = (state = initialState, action) => {
   
  switch (action.type) {
    case LOGIN_SUCCESS:
      return {
        ...state,
        user: action.payload,
        message: 'Login successful!',
       
      };
    case LOGIN_FAILURE:
      return {
        ...state,
        error: action.payload,
        message: 'Login failed!',
      };
    case REGISTER_SUCCESS:
      return {
        ...state,
        user: action.payload,
        message: 'Registration successful!',
      };
    case REGISTER_FAILURE:
      return {
        ...state,
        error: action.payload,
        message: 'Registration failed!',
      };
    default:
      return state;
  }
};

export default UserReducer;
