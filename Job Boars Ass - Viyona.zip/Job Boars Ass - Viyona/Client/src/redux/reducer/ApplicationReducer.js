
export const GET_APPLICATIONS = "GET_APPLICATIONS";
export const CREATE_APPLICATIONS = "CREATE_APPLICATIONS";
export const UPDATE_APPLICATIONS = "UPDATE_APPLICATIONS";
export const DELETE_APPLICATIONS = "DELETE_APPLICATIONS";
export const APPLICATIONS_ERROR = "APPLICATIONS_ERROR";

const initialState = {
  applications: [],
  error: null,
};

const ApplicationReducer = (state = initialState, action) => {
  switch (action.type) {
    case GET_APPLICATIONS:
      return {
        ...state,
        applications: action.payload,
      };
    case CREATE_APPLICATIONS:
      return {
        ...state,
        applications: [...state.applications, action.payload],
      };
    case UPDATE_APPLICATIONS:
      return {
        ...state,
        applications: state.applications.map((job) =>
          job.id === action.payload.id ? action.payload : job
        ),
      };
    case DELETE_APPLICATIONS:
      return {
        ...state,
        applications: state.applications.filter((job) => application.id !== action.payload),
      };
    case APPLICATIONS_ERROR:
      return {
        ...state,
        error: action.payload,
      };
    default:
      return state;
  }
};

export default ApplicationReducer;
