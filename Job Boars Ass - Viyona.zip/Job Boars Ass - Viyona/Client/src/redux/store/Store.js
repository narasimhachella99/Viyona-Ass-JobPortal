
import { configureStore } from '@reduxjs/toolkit';
import { combineReducers } from 'redux';
import UserReducer from '../reducer/UserReducer';
import jobReducer from '../reducer/JobReducer';
import ApplicationReducer from '../reducer/ApplicationReducer';


const rootReducer = combineReducers({
  user: UserReducer,
});

const Store = configureStore({
  reducer: rootReducer,
  job:jobReducer,
  application:ApplicationReducer
});

export default Store;

