import React from "react";
import HomeNav from "../navbars/HomeNav";

const Home = () => {
  return (
    <div>
      <HomeNav />
      <center>
        <div className="col-5 mt-5">
          <h1 className="mt-5 border border-circle">
            {" "}
            Welocome to the Job board application{" "}
          </h1>
        </div>
      </center>
    </div>
  );
};

export default Home;
