import React from "react";
import UserNav from "../navbars/UserNav";

const UserHome = () => {
  return (
    <div>
      <UserNav />
      <center>
        <div className="col-5 mt-5">
          <h1 className="mt-5 border border-circle"> Welocome to your Home </h1>
        </div>
      </center>
    </div>
  );
};

export default UserHome;
