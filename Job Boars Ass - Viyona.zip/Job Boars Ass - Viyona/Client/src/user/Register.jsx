import React, { useEffect } from "react";
import HomeNav from "../navbars/HomeNav";
import { useDispatch, useSelector } from "react-redux";
import { useForm } from "react-hook-form";
import { clearMessages, registerUser } from "../redux/actions/UserAction";
import { useNavigate } from "react-router-dom";

const Register = () => {
  const dispatch = useDispatch();
  const { register, handleSubmit, reset } = useForm();
  const { message, error } = useSelector((state) => state.user);
  const navigate =useNavigate();
  useEffect(() => {
    return () => {
        dispatch(clearMessages());
       
    };
}, [dispatch]);

  const onSubmit = (user) => {
    dispatch(registerUser(user));
    reset();
    return () => {
        dispatch(clearMessages());
    };
  };
  return (
    <div>
      <HomeNav />
      <div className="container mt-5">
        <center>
          <form onSubmit={handleSubmit(onSubmit)} className="mt-5">
            <div className="h2 display-3">Register Here</div>
            {message && <p>{message}</p>}
            {error && <p>{error}</p>}

            <div className="form-group mt-5">
              <input
                type="text"
                {...register("name")}
                className="form-control mt-1 w-50"
                id="exampleInputEmail1"
                aria-describedby="emailHelp"
                placeholder="Enter Username"
              />
            </div>
            <div className="form-group mt-3">
              <input
                type="email"
                {...register("email")}
                className="form-control mt-1 w-50"
                id="exampleInputEmail1"
                aria-describedby="emailHelp"
                placeholder="Enter email"
              />
            </div>
            <div className="form-group mt-3">
              <input
                type="password"
                {...register("password")}
                className="form-control mt-1 w-50"
                id="exampleInputPassword1"
                placeholder="Password"
              />
            </div>
            {/* <div className="form-group mt-3">
              <input
                type="text"
                {...register("address")}
                className="form-control mt-1 w-50"
                id="exampleInputPassword1"
                placeholder="Address"
              />
            </div> */}
            <button type="submit" className="btn btn-primary mt-5">
              Submit
            </button>
          </form>
        </center>
      </div>
    </div>
  );
};
export default Register;
