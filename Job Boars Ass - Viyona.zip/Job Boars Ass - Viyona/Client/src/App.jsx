
import './App.css'
import { BrowserRouter,Routes,Route } from 'react-router-dom'
import Home from './components/Home'
import Login from './user/Login'
import Register from './user/Register'
import UserHome from './user/UserHome'
import AdminHome from './admin/AdminHome'
import UserJobs from './user/UserJobs'
import Applications from './admin/Applications'
function App() {

  return (
    <>
     <BrowserRouter>
     <Routes>
      <Route path='/' element={<Home/>}/>
      <Route path='/login' element={<Login/>}/>
      <Route path='/register' element={<Register/>}/>
      <Route path='/userhome' element={<UserHome/>}/>
      <Route path='/adminhome' element={<AdminHome/>}/>
      <Route path='/userjobs' element={<UserJobs/>}/>
      <Route path='/applications' element={<Applications/>}/>
     </Routes>
     </BrowserRouter>
    </>
  )
}

export default App
