# Viyonatask-jobboardportal

*
## Used Technologies
- ### Backend  : Python, Fastapi
- ### Frontend  : Reactjs
- ### Database : Mysql