import { configureStore } from '@reduxjs/toolkit';
import UserReducer from '../reducer/UserReducer';
import jobReducer from '../reducer/JobReducer';
import ApplicationReducer from '../reducer/ApplicationReducer';

const store = configureStore({
  reducer: { 
    job: jobReducer,
    application: ApplicationReducer,
    user: UserReducer,
  },
});

export default store;

