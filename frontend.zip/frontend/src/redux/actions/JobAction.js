
import axios from 'axios';


export const GET_JOBS = "GET_JOBS";
export const CREATE_JOB = "CREATE_JOB";
export const UPDATE_JOB = "UPDATE_JOB";
export const DELETE_JOB = "DELETE_JOB";
export const JOBS_ERROR = "JOBS_ERROR";

export const fetchJobs = () => async (dispatch) => {
  try {
    const res = await axios.get('https://api.example.com/jobs');
    dispatch({
      type: GET_JOBS,
      payload: res.data,
    });
  } catch (error) {
    dispatch({
      type: JOBS_ERROR,
      payload: error.response.data.message,
    });
  }
};

export const createJob = (jobData) => async (dispatch) => {
  try {
    const res = await axios.post('https://api.example.com/jobs', jobData);
    dispatch({
      type: CREATE_JOB,
      payload: res.data,
    });
  } catch (error) {
    dispatch({
      type: JOBS_ERROR,
      payload: error.response.data.message,
    });
  }
};

export const updateJob = (id, updatedData) => async (dispatch) => {
  try {
    const res = await axios.put(`https://api.example.com/jobs/${id}`, updatedData);
    dispatch({
      type: UPDATE_JOB,
      payload: res.data,
    });
  } catch (error) {
    dispatch({
      type: JOBS_ERROR,
      payload: error.response.data.message,
    });
  }
};


export const deleteJob = (id) => async (dispatch) => {
  try {
    await axios.delete(`https://api.example.com/jobs/${id}`);
    dispatch({
      type: DELETE_JOB,
      payload: id,
    });
  } catch (error) {
    dispatch({
      type: JOBS_ERROR,
      payload: error.response.data.message,
    });
  }
};
