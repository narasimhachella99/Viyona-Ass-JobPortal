
import axios from "axios";
import { loginRequest, loginSuccess, loginFailure, registerSuccess, registerFailure, logout } from "../reducer/UserReducer";



export const userRegister= (user) => async (dispatch) => {

  try {
    const response = await axios.post('http://127.0.0.1:8000/auth/auth/register', user);
    console.log(response);

    dispatch(registerSuccess());
    return response.data;
  } catch (error) {
    dispatch(registerFailure(error.response.data.message));
    throw error;
  }
};

export const login = (loginUser) => async (dispatch) => {
  dispatch(loginRequest());
  try {
    const response = await axios.post('http://localhost:8000/auth/auth/login', loginUser);

    const { token, user_id, role } = response.data; 

   
    dispatch(loginSuccess({ token, user_id, role }));

 
    localStorage.setItem("token", token);
    localStorage.setItem("user_id", JSON.stringify(user_id));  
    localStorage.setItem("role", role);  

    
    return user_id;

  } catch (error) {
    dispatch(loginFailure(error.response?.data?.message || 'Login failed'));
    throw error;
  }
};


export const logoutUser = () => (dispatch) => {
  dispatch(logout());
  localStorage.removeItem("token");
  localStorage.removeItem("user_id");
  localStorage.removeItem("role"); 
};
