
import toast, { Toaster } from 'react-hot-toast';
import { Navigate } from 'react-router-dom';


const ProtectedRoute = ({ element, role }) => {
  const token = localStorage.getItem('token'); 
  const storedUserId = JSON.parse(localStorage.getItem('user_id'));  
  const storedRole = localStorage.getItem('role');  
  
  if (!token || !storedUserId || storedRole !== role) {
    toast.error("Please login with valid credentials");
    return <Navigate to="/login"  />;
  }
  return element;
 
};

export default ProtectedRoute;
