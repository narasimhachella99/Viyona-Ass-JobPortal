import axios from "axios";

// Setup the base URL for your API
const axiosInstance = axios.create({
  baseURL: "http://localhost:5000/api", // replace with your backend API URL
});

// Set up an interceptor to add JWT to requests
axiosInstance.interceptors.request.use((config) => {
  const token = localStorage.getItem("token");
  if (token) {
    config.headers["Authorization"] = `Bearer ${token}`;
  }
  return config;
}, (error) => {
  return Promise.reject(error);
});

export default axiosInstance;
