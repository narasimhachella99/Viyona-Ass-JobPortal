import React, { useEffect, useState } from "react";
import UserNav from "../navbars/UserNav";
import axios from "axios";
import { useForm } from "react-hook-form";
import toast, { Toaster } from "react-hot-toast";
import AdminNav from "../navbars/AdminNav";

const Applications = () => {
  const [tasks, setTasks] = useState([]);
  const addForm = useForm();
  const token = localStorage.getItem("token");
  const getAllTasks = async () => {
    try {
      const token = localStorage.getItem("token");
      if (!token) {
        console.log("No token found, please log in.");
        return;
      }
      const res = await axios.get(
        "http://127.0.0.1:8000/applications/applications/all",
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );
      console.log(res.data);

      if (res.status === 200) {
        setTasks(res.data);
      }
    } catch (error) {
      console.log("Error fetching Jobs: ", error);
    }
  };
  useEffect(() => {
    getAllTasks();
  }, []);
  return (
    <div>
      <AdminNav />
      <div className="card mt-5">
        <div className="card-body">
          <div className="h5">All Jobs</div>
          <div style={{ overflowX: "auto" }}>
            <table className="table table-bordered text-center mt-3">
              <thead>
                <tr>
                  <th>S.No</th>
                  <th>Job Id</th>
                  <th>User Id</th>
                  <th>Date</th>
                  <th>Status</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                {tasks.map((task, index) => (
                  <tr key={task._id}>
                    <td>{index + 1}</td>
                    <td>{task.job_id}</td>
                    <td>{task.user_id}</td>
                    <td>{task.applied_at}</td>
                    <td>{task.status}</td>
                    <td>
                      <button
                        className="btn btn-success"
                        style={{ marginLeft: "6px" }}
                        type="button"
                        onClick={addForm.handleSubmit(async () => {
                          try {
                            const data ={
                              "new_status": "Approved"
                          }
                            const res = await axios.put(
                              `http://127.0.0.1:8000/applications/applications/${task.id}`,data,
                              {
                                headers: {
                                  Authorization: `Bearer ${token}`,
                                },
                              }
                            );
                            if (res.status === 200) {
                              getAllTasks();
                              addForm.reset();
                              toast.success(
                                "Approved successfully"
                              );
                            }
                          } catch (error) {
                            console.log(error);
                            toast.error("Something went wrong");
                          }
                        })}
                      >
                        Approve
                      </button>
                        <button
                        className="btn btn-danger"
                        style={{ marginLeft: "6px" }}
                        type="button"
                        onClick={addForm.handleSubmit(async () => {
                          try {
                            const data ={
                              "new_status": "Rejected"
                          }
                            const res = await axios.put(
                              `http://127.0.0.1:8000/applications/applications/${task.id}`,data,
                              {
                                headers: {
                                  Authorization: `Bearer ${token}`, 
                                },
                              }
                            );
                            if (res.status === 200) {
                              getAllTasks();
                              addForm.reset();
                              toast.success(
                                "Rejected successfully"
                              );
                            }
                          } catch (error) {
                            console.log(error);
                            toast.error("Something went wrong");
                          }
                        })}
                      >
                        Reject
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
      <Toaster />
    </div>
  );
};

export default Applications;
