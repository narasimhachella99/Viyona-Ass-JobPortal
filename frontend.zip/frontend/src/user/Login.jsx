import React from "react";
import HomeNav from "../navbars/HomeNav";
import { useDispatch, useSelector } from "react-redux";
import { useForm } from "react-hook-form";
import { useNavigate } from "react-router-dom";
import { login } from "../redux/actions/UserAction";
import toast, { Toaster } from "react-hot-toast";

const Login = () => {
  const dispatch = useDispatch();
  const { register, handleSubmit } = useForm();
  const { message } = useSelector((state) => state.user);
  const history = useNavigate();
  const onSubmit =async (user) => {
    try {
       await dispatch(login(user));
      const role = localStorage.getItem('role');

      if (role === 'admin') {
       
        history('/adminhome');
      } else if (role === 'user') {
       
        history('/userhome');
        toast.success("Login successful")
      }
    
    } catch (error) {
      console.log(error);
      toast("Login failed");
    }
  };
  return (
    <div>
      <HomeNav />
      <div className="container mt-5">
        <center>
          <form onSubmit={handleSubmit(onSubmit)} className="mt-5">
            <div className="h2 display-3">Login Here</div>
            {message && <p>{message}</p>}
            <div className="form-group mt-5">
              <input
                type="email"
                {...register("email")}
                className="form-control mt-3 w-50"
                id="exampleInputEmail1"
                aria-describedby="emailHelp"
                placeholder="Enter Username"
              />
            </div>
            <div className="form-group mt-5">
              <input
                type="password"
                {...register("password")}
                className="form-control mt-3 w-50"
                id="exampleInputPassword1"
                placeholder="Password"
              />
            </div>
            <button type="submit" className="btn btn-primary mt-5">
              Submit
            </button>
          </form>
        </center>
      </div>
      <Toaster/>
    </div>
  );
};

export default Login;
