import axios from 'axios';
import React, { useEffect, useState } from 'react'
import UserNav from '../navbars/UserNav';
import { Toaster } from 'react-hot-toast';

const MyApplications = () => {
    const [tasks, setTasks] = useState([]);
    const getAllTasks = async () => {
    try {
      const token = localStorage.getItem('token');
      if (!token) {
        console.log("No token found, please log in.");
        return; 
      }
      const res = await axios.get('http://127.0.0.1:8000/applications/applications/my-applications',{
        headers: {
          Authorization: `Bearer ${token}`  
        }
      });
      if (res.status === 200) {
        setTasks(res.data);
      }
    } catch (error) {
      console.log("Error fetching Jobs: ", error);
    }
    };
    useEffect(() => {
      getAllTasks();
    }, []);
  return (
    <div>
          <UserNav/>
        <div className="card mt-5">
        <div className="card-body">
          <div className="h5">My applications</div>
          <div style={{ overflowX: "auto" }}>
            <table className="table table-bordered text-center mt-3">
              <thead>
                <tr>
                  <th>S.No</th>
                  <th>Application Id</th>
                  <th>Date </th>
                  <th>Status</th>
                </tr>
              </thead>
              <tbody>
                {tasks.map((task, index) => (
                  <tr key={task._id}>
                    <td>{index + 1}</td>
                    <td>{task.job_id}</td>
                    <td>{task.applied_at}</td>
                    <td>{task.status}</td> 
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
      <Toaster/>
    </div>
  )
}

export default MyApplications;