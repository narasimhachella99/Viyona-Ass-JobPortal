import React from "react";
import { useForm } from "react-hook-form";


import toast, { Toaster } from 'react-hot-toast';
import { useNavigate } from "react-router-dom";
import HomeNav from "../navbars/HomeNav";
import { userRegister } from "../redux/actions/UserAction";
import { useDispatch } from "react-redux";
const Register = () => {
  const { register, handleSubmit } = useForm();
  const history = useNavigate();
  const dispatch =useDispatch();
  const onSubmit = async (data) => {
    try {
      await dispatch(userRegister(data));
      toast.success("Registration successful");
      history("/login"); 
    } catch (error) {
      console.log(error);
      toast("Registration failed");
    }
  };

  return (
    <div>
       <HomeNav />
      <div className="container mt-5">
        <center>
          <form onSubmit={handleSubmit(onSubmit)} className="mt-5">
            <div className="h2 display-3">Register Here</div>
            <div className="form-group mt-5">
              <input
                type="text"
                {...register("name")}
                className="form-control mt-1 w-50"
                id="exampleInputEmail1"
                aria-describedby="emailHelp"
                placeholder="Enter Username"
              />
            </div>
            <div className="form-group mt-3">
              <input
                type="email"
                {...register("email")}
                className="form-control mt-1 w-50"
                id="exampleInputEmail1"
                aria-describedby="emailHelp"
                placeholder="Enter email"
              />
            </div>
            <div className="form-group mt-3">
              <input
                type="password"
                {...register("password")}
                className="form-control mt-1 w-50"
                id="exampleInputPassword1"
                placeholder="Password"
              />
            </div>
            <button type="submit" className="btn btn-primary mt-5">
              Submit
            </button>
          </form>
        </center>
      </div>
      <Toaster />
    </div>
  );
};

export default Register;
